
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/templates.css" type="text/css">
    <title>SCHOOL</title>

    <style>
        *{
            margin:0;
            padding:0;
        }
        .title{¡
            color:black;
            width:100%;
            display:flex;
            justify-content:center;
        }
        .aside{
            display: flex;
            width:100%;
            flex-direction:row;
            justify-content: space-around;
            align-self: center;
            margin-top:20px;
            margin-bottom:20px;
        }
        a{
            color:black;
        }
        .tareas{
            display:flex;
            justify-content:center;
        }
        .sesion{
            text-align:center;
            display:flex;
            justify-content:center;
            margin:10px;

        }
    </style>

</head>
<body>
    <header>
    <h1 class="title">SCHOOL</h1>

    </header>
    <aside class="aside">
    <div class="login">
            <a href="?url=login">Home</a>
            </div>
            <div class="login">
            <a href="?url=list">Listas</a>
            </div>
            <div class="register">
            <a href="?url=task">Tareas</a>
            </div>
            </aside>
            <br>
            <div class="sesion">
            <?php 
                session_start();
                require APP."/config.php";
                require APP."/lib/conn.php";

                echo 'Hola, '.$_SESSION["username"];
                echo '<br>';
                echo 'Usuario: '.$_SESSION["username"];
                echo '<br>';
                echo 'Email: '.$_SESSION["email"]."<br>";
            ?>
            </div>
            <br>
            <div class="tareas">
            <?php

                $db=getConnection($dsn,$dbuser,$dbpasswd);
                $statement = $db->prepare("SELECT * from task where username_id='".$_SESSION['usernameid']."';");
                $statement-> execute();
                //FETCH_ASSOC-> convertir en array asociativo
                $peticion = $statement->fetchAll(PDO::FETCH_ASSOC);

                foreach($peticion as $values){
                    $nombretarea=$values['task'];
                    $nombrelista=$values['list_task'];
                    if(empty($nombretarea)==false && empty($nombrelista)==false){
                            echo "Tarea: ".$nombretarea."<br>
                            Lista: ".$nombrelista."<br><br>";
                    }
                }
            ?>
            </div>

            
    <main>
    </main>
</body>
</html>