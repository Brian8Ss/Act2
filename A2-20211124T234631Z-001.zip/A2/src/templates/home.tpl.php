<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/templates.css" type="text/css">
    <title>SCHOOL</title>

    <style>
        *{
            margin:0;
            padding:0;
        }
        .title{
            margin-top:10%;
            width:100%;
            color:black;
            display:flex;
            justify-content:center;
        }
        .aside{
            margin-top:10%;
            display: flex;
            width:100%;
            flex-direction:row;
            justify-content: space-around;
            align-self: center;
        }
        a{
            color:black;
        }
    </style>

</head>
<body>
    <header>
    <h1 class="title">SCHOOL</h1>

    </header>
    <aside class="aside">
            <div class="login">
                <a href="?url=login">Login</a>
            </div>
            <div class="register">
                <a href="?url=register">Register</a>

            </div>

            
    </aside>
    <main>
    </main>
</body>
</html>