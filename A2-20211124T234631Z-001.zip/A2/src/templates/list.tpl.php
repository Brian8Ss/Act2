<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/templates.css" type="text/css">
    <title>dashboard</title>

    <style>
        *{
            margin:0;
            padding:0;

        }
        .title{
            color:black;
            display:flex;
            justify-content:center;
        }
        .aside_home{
            display:flex;
            justify-content:space-around;
            width:100%;
            margin-left:15%;
        }
        .aside2{
            display:flex;
            justify-content:space-around;
            width:100%;
        }
        main{
            display:flex;
            justify-content:center;
        }
        .boton1{
            display:flex;
            justify-content:center;
            width: 100%;
            padding: 15px;
            cursor: pointer;
        }

        main{
            display:flex;
            justify-content:center;
        }
        main{
            border: 2px solid black;
            margin: 30px 800px 30px 800px
        }
        .login{
           text-align:center;
           font-size:25px;
        }
    </style>

</head>
<body>
    
    
    <h1 class="title">SCHOOL</h1>
    <aside class="aside_home">
        <a href="?url=escritorio">escritorio</a>
        <a href="?url=task">añadir tareas</a>
        <br><br>
        </aside> 
        <aside class="aside2">
    <?php 
            session_start();
            echo "LISTAS<br>";
            echo 'Hola, '.$_SESSION["username"];
    ?>
        </aside> 
<main>
    <form action="?url=list_action" method="post">
    <h3 class="login">LISTAS</h3><br>
       <h4>Name list</h4>
        <input type="list" name="list" placeholder="list" required>
        <br><br>
        <div> <button type="submit" name="boton" class="boton1">Registrar</button></div>
    </form>
</main>

  
</body>
</html>