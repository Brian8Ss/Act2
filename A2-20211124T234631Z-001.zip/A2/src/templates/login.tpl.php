<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>

    <style>
        *{
            margin:0;
            padding:0;

        }
        .title{
            color:black;
            display:flex;
            justify-content:center;
            margin-top:10%;
        }
        .aside{
            width: 100%;
            display:flex;
            justify-content:center;
        }
        main{
            display:flex;
            justify-content:center;
        
        }
        .boton1{
            display:flex;
            justify-content:center;
            width: 100%;
            padding: 15px;
            cursor: pointer;
        }
        main{
            margin: 30px 400px 30px 400px
        }
        .login{
           text-align:center;
           font-size:25px;
        }

    </style>

</head>
<body> 

<h1 class="title">SCHOOL</h1>

<aside class="aside">
                <a href="?url=home">Home</a>
                <a href="?url=register">Register</a>
        </ul>
</aside> 

    <main>
        <form action="?url=login_action" method="post">
        <h3 class="login">LOGIN</h3><br>
            <input type="text" name="username" placeholder="Username">
            <input type="password" name="passwd" placeholder="Password">
            <br><br>
            <div> <button type="submit" name="boton" class="boton1">Login</button></div>
        </form>
    </main>
 

</body>
</html>