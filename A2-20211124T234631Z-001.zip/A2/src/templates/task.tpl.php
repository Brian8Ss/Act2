<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/templates.css" type="text/css">
    <title>dashboard</title>

    <style>
        *{
            margin:0;
            padding:0;
            margin-top:2%;
        }
        .title{
            color:black;
            display:flex;
            justify-content:center;
        }
        .aside{
            display:flex;
            justify-content:space-around;
            flex-direction:row;
        }
        .boton1{
            display:flex;

            width: 100%;
            cursor: pointer;
        }

        main{
            display:flex;
            justify-content:center;
            border: 2px solid black;
            margin-left:40%;
            margin-right:40%;
        }
        .boton1{
            display:flex;
            justify-content:center;
            width: 100%;
            cursor: pointer;
        }
        .login{
           text-align:center;
           font-size:25px;
        }
    </style>
</head>
<body>
    
    <h1 class="title">SCHOOL</h1>
    </aside>
    <aside class="aside">
        <a href="?url=escritorio">escritorio</a>
        <a href="?url=list">añadir lista</a>
        
        
        
    <?php 
                session_start();
                echo "TAREAS<br>";
                echo 'Hola, '.$_SESSION["username"];
            ?></aside>
  <main>
    <form action="?url=task_action" method="post">
    <h3 class="login">TAREAS</h3><br>
     
        <h4>Name list</h4>
        <input type="text" name="nombrelista" placeholder="list" required>
        <br><br>

       <h4>Name task</h4>
        <input type="text" name="nombretarea" placeholder="task" required>
        <br><br>
        <div> <button type="submit" name="boton" class="boton1">Registrar</button></div>
    </form>

</main>
</body>
</html>