<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>register</title>

    <style>
        *{
            margin:0;
            padding:0;

        }
        .title{
            color:black;
            display:flex;
            justify-content:center;
        }
        .aside{
            display:flex;
            justify-content:space-around;
        }
        main{
            display:flex;
            justify-content:center;
        }
        .boton1{
            display:flex;
            justify-content:center;
            width: 100%;
            cursor: pointer;
        }
        main{
            border: 2px solid black;
            margin: 30px 800px 30px 800px
        }
        .register{
           text-align:center;
           font-size:25px;
        }
    </style>

</head>
<body>

<h1 class="title">SCHOOL</h1>
    <aside class="aside">
                <a href="?url=home">Home</a>

                <a href="?url=login">Login</a>
    </aside>

    <main>
    
        <form action="?url=register_action" method="post">
        <h3 class="register">REGISTER</h3><br>
            <p>
            <input type="email" name="email" placeholder="Email" required>
            </p>
            <p>
            <input type="text" name="username" placeholder="Username" required> 
            </p>  
            
            <p>
            <input type="password" name="passwd" placeholder="Password" required>
            </p> 
            <p>
            <input type="password" name="passwd2" placeholder="Repeat password" required>
            </p>
                
            
            <br>
            <p>
            <button type="submit" name="boton_registrar" class="boton1">Register</button>
            </p>
                
        </form>

    </main>
</body>
</html>