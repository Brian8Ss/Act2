<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>

    <style>
        *{
            margin:0;
            padding:0;
            color: black;
            font-size: 20px;
        }
        
        }
        .boton1{
            display:flex;
            justify-content:center;
            width: 100%;
            cursor: pointer;

    </style>

</head>
<body> 

<?php
session_start();
//Accion login
//require APP.'src/db/database.php';
require APP."/config.php";
require APP."/lib/conn.php";
$username= filter_input(INPUT_POST,'username');
$passwd=filter_input(INPUT_POST,'passwd');
$boton_login=filter_input(INPUT_POST,'boton');

$db=getConnection($dsn,$dbuser,$dbpasswd);
$statement = $db->prepare("SELECT * from users WHERE username = '".$username."' AND passwd = '".$passwd."';");

$statement-> execute();
//FETCH_ASSOC-> convertir en array asociativo
$peticion = $statement->fetchAll(PDO::FETCH_ASSOC);

foreach($peticion as $user){
    $campoemail = $user['email'];
    $_SESSION['usernameid'] = $user['id'];
}

//empty -> variable vacía
if(empty($peticion)){
    echo "El usuario o contraseña que has introducido son incorrectos"; 
    echo "<br><br><a href='?url=login'> login </a>";
} else {
    //variables sesion email, usuario
    $_SESSION["username"]=$username;
    $_SESSION["email"]=$campoemail;
    header("Location:?url=escritorio");
    
}

?>

</body>
</html>
