<?php
//Accion register
//require APP.'src/db/database.php';
require APP."/config.php";
require APP."/lib/conn.php";

$email=filter_input(INPUT_POST,'email');
$username= filter_input(INPUT_POST,'username');
$passwd=filter_input(INPUT_POST,'passwd');
$passwd2=filter_input(INPUT_POST,'passwd2');
$boton=filter_input(INPUT_POST, 'boton_registrar');

$db=getConnection($dsn,$dbuser,$dbpasswd);


$statement = $db->prepare("INSERT INTO users (username,email,passwd) VALUE (?,?,?);");



if($passwd==$passwd2){
    $statement->execute([$username,$email,$passwd]);
     header("Location: ?url=home");
} else {
    echo "las contraseñas no coinciden";

}
   