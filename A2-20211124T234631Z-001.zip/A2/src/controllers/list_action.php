<?php
//Accion register lista
//require APP.'src/db/database.php';
require APP."/config.php";
require APP."/lib/conn.php";
session_start();

$list=filter_input(INPUT_POST,'list');
$boton=filter_input(INPUT_POST, 'boton_registrar');

$db=getConnection($dsn,$dbuser,$dbpasswd);
$statement = $db->prepare("INSERT INTO list (username_id,list) VALUE (?,?);");
$statement-> execute();
//FETCH_ASSOC-> convertir en array asociativo
$peticion = $statement->fetchAll(PDO::FETCH_ASSOC);



//guardamos el id del usuario con el que  nos hemos conectado
$statementuser = $db->prepare("SELECT id from users where username='".$_SESSION["username"]."';");
$statementuser-> execute();
//FETCH_ASSOC-> convertir en array asociativo
$peticion1 = $statementuser->fetchAll(PDO::FETCH_ASSOC);

foreach($peticion1 as $id){
   $username1=$id['id'];
}



if (empty($list)==false){
    $statement->execute([$username1,$list]);
    header("Location:?url=escritorio");
}