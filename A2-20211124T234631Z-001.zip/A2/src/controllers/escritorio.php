<?php

require APP.'/lib/render.php';
//  renders login template
echo render('escritorio',[]);
