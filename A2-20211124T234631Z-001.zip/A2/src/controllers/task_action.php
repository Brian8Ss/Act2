
<?php
session_start();
//Accion login
//require APP.'src/db/database.php';

require APP."/config.php";
require APP."/lib/conn.php";
$nombretarea= filter_input(INPUT_POST,'nombretarea');
$boton_login=filter_input(INPUT_POST,'boton');
$nombrelista=filter_input(INPUT_POST,'nombrelista');
$db=getConnection($dsn,$dbuser,$dbpasswd);

//guardamos el id del usuario con el que  nos hemos conectado
$statementuser = $db->prepare("SELECT * from users where username='".$_SESSION["username"]."';");
$statementuser-> execute();
//FETCH_ASSOC-> convertir en array asociativo
$peticion1 = $statementuser->fetchAll(PDO::FETCH_ASSOC);


foreach($peticion1 as $user){
    $idusername=$user['id'];
}

$statement = $db->prepare("INSERT INTO task (username_id,task,list_task) VALUES (?,?,?);");
$statement->execute();
//FETCH_ASSOC-> convertir en array asociativo
$peticion = $statement->fetchAll(PDO::FETCH_ASSOC);

//empty -> variable vacía

if(empty($nombretarea && $nombrelista)==false){
    $statement->execute([$idusername,$nombretarea,$nombrelista]);
    header("Location:?url=escritorio");
    
    
} else {
    echo "Hola";
}


?>