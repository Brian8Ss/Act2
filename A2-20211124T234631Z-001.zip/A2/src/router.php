<?php
    /**
     * Returns url route
     * 
     */
    function getRoute():string{
        if(isset($_REQUEST['url'])){
            $url=$_REQUEST['url'];
        }else{
            $url='home';
        }
        switch($url){
            //acceso a vista
            case 'login';
                return 'login';
            case 'register';
                return 'register';
            //acceso a proceso login
            case 'login_action';
                return 'login_action';
            case 'register_action';
                return 'register_action';
            case 'escritorio';
                return 'escritorio';
            case 'list';
                return 'list';
            case 'list_action';
                return 'list_action';
            case 'task';
                return 'task';
            case 'task_action';
                return 'task_action';
            default:
                return 'home';
        }
    }