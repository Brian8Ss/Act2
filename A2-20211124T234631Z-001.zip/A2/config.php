<?php 
    define('APP',__DIR__);
    //DATOS acceso a BBDD
    $dbhost=$_ENV['DB_HOST']; 
    $dbuser=$_ENV['DB_USER'];
    $dbname=$_ENV['DB_NAME']; //nombre tabla
    $dbpasswd=$_ENV['DB_PASSWORD'];; // contraseña de usuario
    $dsn='mysql:host='.$dbhost.';dbname='.$dbname.';charset=utf8mb4';
?>