<?php  
    //establecer errores
    /*ini_set('display_errors','On');*/
    session_start();
    require 'vendor/autoload.php';
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
    $dotenv->load();
    
    require_once 'config.php';
    require_once 'src/router.php';
   
    $controller=getRoute();
    //var_dump($controller);
    //die();
    require APP.'/src/controllers/'.$controller.'.php';
